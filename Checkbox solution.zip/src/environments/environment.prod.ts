export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyCht9gsEp4V0Ea75tHD9hCa9ehlaSWk2WE",
    authDomain: "tomsproductdatabase-3cf5d.firebaseapp.com",
    databaseURL: "https://tomsproductdatabase-3cf5d.firebaseio.com",
    projectId: "tomsproductdatabase-3cf5d",
    storageBucket: "tomsproductdatabase-3cf5d.appspot.com",
    messagingSenderId: "960928748150"
  }
};
